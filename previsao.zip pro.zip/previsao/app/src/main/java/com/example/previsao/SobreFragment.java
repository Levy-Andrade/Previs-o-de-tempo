package com.example.previsao;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class SobreFragment extends Fragment {

    public SobreFragment() {
        // Requer um construtor vazio
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Infla o layout para este fragmento
        View view = inflater.inflate(R.layout.fragment_sobre, container, false);

        // Exibir informações sobre o usuário
        TextView textView = view.findViewById(R.id.text_view_sobre);
        textView.setText("Nome: Levy de Andrade da Silva\nRA: 09043510\nCurso: Programação de Dispositivos Moveis");

        return view;
    }
}
