package com.example.previsao;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

public class PrevisaoFragment extends Fragment {

    public PrevisaoFragment() {
        // Requer um construtor vazio
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Infla o layout para este fragmento
        View view = inflater.inflate(R.layout.fragment_previsao, container, false);

        // Configuração do RecyclerView
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Criando a lista de previsões
        List<Previsao> previsoes = new ArrayList<>();
        previsoes.add(new Previsao("03/11", "23°C", "Ensolarado"));
        previsoes.add(new Previsao("04/11", "19°C", "Nublado"));
        previsoes.add(new Previsao("05/11", "25°C", "Chuvoso"));

        // Configurando o adapter para o RecyclerView
        PrevisaoAdapter adapter = new PrevisaoAdapter(previsoes);
        recyclerView.setAdapter(adapter);

        return view;
    }
}
