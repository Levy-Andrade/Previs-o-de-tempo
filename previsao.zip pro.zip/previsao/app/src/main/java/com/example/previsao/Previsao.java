package com.example.previsao;

public class Previsao {
    private String data;
    private String temperatura;
    private String descricao;

    // Construtor
    public Previsao(String data, String temperatura, String descricao) {
        this.data = data;
        this.temperatura = temperatura;
        this.descricao = descricao;
    }

    // Getters
    public String getData() {
        return data;
    }

    public String getTemperatura() {
        return temperatura;
    }

    public String getDescricao() {
        return descricao;
    }
}
